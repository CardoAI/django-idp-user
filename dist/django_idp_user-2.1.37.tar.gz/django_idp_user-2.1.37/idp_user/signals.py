from django.dispatch import Signal

pre_update_idp_user = Signal()
post_update_idp_user = Signal()

post_create_idp_user = Signal()
