#!/bin/bash -e

coverage run -m pytest -v
