from idp_user.utils.choices import ChoicesMixin


class ROLES(ChoicesMixin):
    test_role = "test_role"
